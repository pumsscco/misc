# plutochan2
www2.plutochan.name 为现有Django项目的归档备份,有以下子项目

* www2.plutochan.name/pal4 仙剑4数据分析
* www2.plutochan.name/stock 股票数据分析

本库不会再增加任何子项目（新项目一律用golang实现），未来不排除使用python3将项目重构，并优化代码
