#!/usr/bin/python
#coding=utf-8
from collections import OrderedDict
print OrderedDict({'efe_water':'水','efe_fire':'火','efe_thunder':'雷','efe_air':'风','efe_earth':'土'})
